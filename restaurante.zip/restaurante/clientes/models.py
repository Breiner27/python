from django.db import models
from django.contrib.auth.models import User

class Cliente(models.Model):
    user=models.OneToOneField(User,on_delete=models.CASCADE)
    telefono=models.CharField(max_length=10)
    direccion=models.TextField()
    fecha_nacimiento=models.DateField(null=True,blank=True)
    fecha_registro=models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"perfil de {self.user.username}"
    
    class Meta:
        verbose_name_plural="Perfiles de usuario"