from django.contrib import admin
from .models import Cliente

@admin.register(Cliente)
class PerfilUsuarioAdmin(admin.ModelAdmin):
    list_display=['user','telefono','fecha_registro']
    search_fields=['cliente__username','telefono']