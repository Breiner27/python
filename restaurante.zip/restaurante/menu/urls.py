from django.urls import path
from . import views

app_name='menu'

urlpatterns=[
    path('',views.inicio,name='inicio'),
    path('menu/',views.MenuView.as_view(), name='menu'),
    path('plato/<int:pk>/',views.plato_detalle,name='plato_detalle'),
    path('agregar/<int:plato_id>/',views.agregar_al_carrito,name='agregar_al_carrito'),
]