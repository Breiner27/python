from django.shortcuts import render, get_object_or_404
from django.views.generic import ListView
from .models import Plato, Categoria

class MenuView(ListView):
    model = Plato
    template_name = 'menu/menu.html'
    context_object_name = 'platos'

    def get_queryset(self):
        return Plato.objects.filter(disponible=True)
    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['categorias'] = Categoria.objects.filter(activo=True)
        return context

# ✅ Esta función debe ir fuera de la clase
def plato_detalle(request, pk):
    plato = get_object_or_404(Plato, pk=pk)
    return render(request, 'menu/plato_detalle.html', {'plato': plato})

def agregar_al_carrito(request,plato_id):
    plato=get_object_or_404(Plato,id=plato_id)
    carrito=request.session.get('carrito',{})
    if str(plato_id) in carrito:
        carrito[str(plato_id)]['cantidad']+=1
    else:
        carrito[str(plato_id)]={
            'nombre':plato.nombre,
            'precio':str(plato.precio),
            'cantidad':1
        }
    request.session['carrito']=carrito
    return redirect('menu:menu')

def inicio(request):
    platos_destacados=Plato.objects.filter(disponible=True)[:6]
    return render (request,'inicio.html',{'platos':platos_destacados})