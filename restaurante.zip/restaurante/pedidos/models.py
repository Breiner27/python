from django.db import models
from django.contrib.auth.models import User
from menu.models import Plato

class Pedidos(models.Model):
    ESTADO_CHOISES = [
        ('pendiente', 'pendiente'),
        ('confirmado', 'confirmado'),
        ('preparando', 'preparando'),
        ('listo', 'listo'),
        ('entregado', 'entregado'),
        ('cancelado', 'cancelado')
    ]
    cliente = models.ForeignKey(User, on_delete=models.CASCADE)
    fecha_pedido = models.DateTimeField(auto_now_add=True)
    estado = models.CharField(max_length=30, choices=ESTADO_CHOISES, default='pendiente')
    total = models.DecimalField(max_digits=10, decimal_places=2)
    direccion_entrega = models.TextField()
    telefono=models.CharField(max_length=15,default=0000000000)
    notas = models.TextField()

    def __str__(self):
        return f"Pedido#{self.id} - {self.cliente.username}"
    
    class Meta:
        ordering = ['-fecha_pedido']


class DetallePedido(models.Model):
    pedido = models.ForeignKey(Pedidos, on_delete=models.CASCADE, related_name='detalles')
    plato = models.ForeignKey(Plato, on_delete=models.CASCADE)
    cantidad = models.IntegerField(default=1)
    precio_unitario = models.DecimalField(max_digits=8, decimal_places=2)

    def __str__(self):
        return f"{self.cantidad}x {self.plato.nombre}"
    
    @property
    def subtotal(self):
        return self.cantidad * self.precio_unitario       