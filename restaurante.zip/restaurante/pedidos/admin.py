from django.contrib import admin
from .models import Pedidos,DetallePedido

class DetallePedidoInLine(admin.TabularInline):
    model=DetallePedido
    extra=0

@admin.register(Pedidos)
class PedidoAdmin(admin.ModelAdmin):
    list_display=['id','cliente','fecha_pedido','estado','total']
    list_filter=['estado','fecha_pedido']
    search_fields=['user__username','id']
    inlines=[DetallePedidoInLine]
    readonly_fields=['fecha_pedido','total']

